<?php
/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 */
define('AUTH_KEY',         'V54fIcXqLbrx4dvPac1g80V3A4bTyVQqyCG789UMbjoSxm0tMYq04TIUKsyNYEKT');
define('SECURE_AUTH_KEY',  '2i50wMjVie7Snn43YF9d5qSySpAW51K7peYY95Ho4o9w2icMtCnproRivnKgVBbD');
define('LOGGED_IN_KEY',    'fYLysgWVKTJ4rN7iA84RMwcHxGhdmhJD5o6yeddPPfnuyXqAA3rEiEjiCMydeI4Q');
define('NONCE_KEY',        'sr4BtwryYxHqMAqDoXaRuXeM0AoTzDbzYLLGammX3LxeEd78XVsVprLrm6MQtc6C');
define('AUTH_SALT',        'esVQLUKhguQt7uaCN8LyiznNwC7BTnxm4nQhFRUorqNj3DIWmw5Tfi317APSMHRN');
define('SECURE_AUTH_SALT', 'nRKN4CAGMvWI690zDGVDQBLVzjri0TItnLc81ENKyYQmWuziEHN04bQNdIGHCGjf');
define('LOGGED_IN_SALT',   'TW18FriHejoe3ySKTfhX0y5t4nrz52aGTiy2YRs6dEvCXMCd7riQXw6GKErxfF8x');
define('NONCE_SALT',       'wB1fq6Ijw7XrpFrSLdM7qz8m00TV1Svmxqvc49s2ydVMGV9Ngu4veDEIA3gpWvB9');
