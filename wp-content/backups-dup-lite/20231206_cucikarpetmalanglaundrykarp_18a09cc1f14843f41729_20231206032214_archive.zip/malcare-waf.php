<?php
// Please validate auto_prepend_file setting before removing this file

if (file_exists('/home/1095496.cloudwaysapps.com/cehryntbrg/public_html/wp-content/plugins/malcare-security/protect/prepend/ignitor.php')) {
	define("MCDATAPATH", '/home/1095496.cloudwaysapps.com/cehryntbrg/public_html/wp-content/mc_data/');
	define("MCCONFKEY", 'b504591304b46c57e54945919bf9d6e5');
	include_once('/home/1095496.cloudwaysapps.com/cehryntbrg/public_html/wp-content/plugins/malcare-security/protect/prepend/ignitor.php');
}
